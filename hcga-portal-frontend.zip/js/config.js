// ============================================================
// KONFIGURASI — satu-satunya tempat yang perlu diubah
// Isi dengan URL /exec dari Deploy → Web App di Google Apps Script.
// ============================================================
const CONFIG = {
  GAS_URL: 'https://script.google.com/macros/s/GANTI_DENGAN_ID_DEPLOYMENT/exec'
};
